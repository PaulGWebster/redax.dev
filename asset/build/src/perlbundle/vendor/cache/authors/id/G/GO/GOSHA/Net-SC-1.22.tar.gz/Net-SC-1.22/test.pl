#!/usr/bin/perl
use Net::SC;
print "Ok\n";

package BaseClass;
use Moose;

no Moose;

1;

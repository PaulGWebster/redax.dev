samba-smbstatus
===============

Samba::Smbstatus - Read active Samba server data from smbstatus
